= postgres-ha (1)
Crunchy Data
2019
== NAME
Crunchy postgres-ha - provides the ability to create highly-available PG clusters\&.

== DESCRIPTION
The Crunchy postgres\-ha container is used for the deployment and management of highly-available 
PostgreSQL clusters created using Patroni\&.

The container itself consists of:
    - RHEL7 base image
    - Postgres binary packages
    - Patroni

== USAGE
See the crunchy docs.

The Red Hat Enterprise Linux version from which the container was built. For example, Version="7.7"

`Release=`

The specific release number of the container. For example, Release="2.4.2"
