#!/bin/bash

# This file is sourced by the start.sh script. Changes made to environment
# variables or adding environment variables will take effect in the shell
# postgres is running in. Anything added to this file will be executed
# prior to the start of the postgres server

echo_info "Executing pre-start-hook..." # add below this line
